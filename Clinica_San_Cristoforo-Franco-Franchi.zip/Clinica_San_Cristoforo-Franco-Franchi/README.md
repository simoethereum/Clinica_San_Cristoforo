Franco Franchi

Nato a Cagliari il 01/01/1953

Ha fatto una lastra alla mano sinistra il 15/09/2017.
